# Alkemy
University project provided by Alkemy. Simulation of an ecommerce market analysis and strategic consultancy for a possible client in the retail sector.

Code is splitted in different notebook as different lenguages and task were performed in each of them. The tasks carried out are:

Task 0: Explorative data analysis

Task 1: Market insights, leader and follower analysis, competitors automated pricing system detection

Task 2: Product segmentation, popoularity index, ABC analysis

Task 0 and 2 are performed in Python while task 2 is entirely carried out in Pyspask.

PS: the csv files uploaded here on GitHub are reduced sample becouse they were very heavy. Dm me if you need the full datasets
